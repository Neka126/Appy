(function() {

//prevent right-clicking for get into console
window.oncontextmenu = (e) => {
    e.preventDefault();
};

function generatePattern(domains) {
    return domains.map((el) => {
        return `https://*.${el}/*`;
    });
}

function disablePopup() {
    chrome.browserAction.setPopup({popup: ''});
}

try {
    throw (new Error('exception'));
} catch(e) {
    const ln = e.stack.match(/anticheat\.js:(\d+)/);
    if (ln && ln.length > 2 && ln[1] !== 19) {
        disablePopup();   
    }
}

let knownGlobals = ['skidBot', 'spider_bot', 'gameBot', 'resetHack', 'Aimbot'];

//periodically check window for unwanted vars
function checkVars() {
    knownGlobals.forEach(key => {
        if (window.hasOwnProperty(key)) {
            disablePopup();
            return;
        }
    });
}
setInterval(checkVars, 60 * 1000);

//get blocking rules
superagent.get('https://bmbrman.site/bomberman/' + chrome.runtime.getManifest().version + '/ac_settings.json')
    .set('X-Requested-With', 'XMLHttpRequest')
    .set('Accept', 'application/json')
    .then(res => {
        const result = res.body;
        if (result.hasOwnProperty('block_domains') && result.block_domains.length) {
            const urlPatterns = generatePattern(result.block_domains);
            
            //block request from game page to external resources distributing cheats
            chrome.webRequest.onBeforeRequest.addListener(function(requestDetails) {
                return {cancel: true};
            }, {urls: urlPatterns, tabId: -1, types: ['xmlhttprequest', 'script']}, ["blocking"]);
        }

        if (result.hasOwnProperty('check_vars') && result.check_vars.length) {
            for (var i = 0, l = result.check_vars.length; i < l; i++) {
                if (knownGlobals.indexOf(result.check_vars[i]) == -1) {
                    knownGlobals.push(result.check_vars[i]);
                }
            }
        }
    });
})();

try {
    throw (new Error('exception'));
} catch(e) {
    const ln = e.stack.match(/anticheat\.js:(\d+)/);
    if (ln && ln.length > 2 && ln[1] !== 66) {
        disablePopup();
    }
}

if (typeof drawBonuses === 'function' 
    && drawBonuses.toString() !== 'function drawBonuses() {\n        // Cache woods tiles\n        var woods = [];\n        for (var i = 0; i < this.tiles.length; i++) {\n            var tile = this.tiles[i];\n            if (tile.material == "wood") {\n                woods.push(tile);\n            }\n        }\n\n        // Sort tiles randomly\n        woods.sort(function() {\n            return 0.5 - Math.random();\n        });\n\n        // Distribute bonuses to quarters of map precisely fairly\n        for (var j = 0; j < 4; j++) {\n            var bonusesCount = Math.round(woods.length * this.bonusesPercent * 0.01 / 4);\n            var placedCount = 0;\n            for (var i = 0; i < woods.length; i++) {\n                if (placedCount > bonusesCount) {\n                    break;\n                }\n\n                var tile = woods[i];\n                if ((j == 0 && tile.position.x < this.tilesX / 2 && tile.position.y < this.tilesY / 2)\n                    || (j == 1 && tile.position.x < this.tilesX / 2 && tile.position.y > this.tilesY / 2)\n                    || (j == 2 && tile.position.x > this.tilesX / 2 && tile.position.y < this.tilesX / 2)\n                    || (j == 3 && tile.position.x > this.tilesX / 2 && tile.position.y > this.tilesX / 2)) {\n\n                    var typePosition = placedCount % 3;\n                    var bonus = new Bonus(tile.position, typePosition);\n                    this.bonuses.push(bonus);\n\n                    // Move wood to front\n                    this.moveToFront(tile.bmp);\n\n                    placedCount++;\n                }\n            }\n        }\n    }') {
    disablePopup();
}

function checkScore(scoreEnc) {
    let res = false;
    const d = '481523';
    if ("-" == scoreEnc[0]) {
        let output = "";
        for (let i = 1, l = scoreEnc.length; i < l;) {
            for (var e = 0, f = 1; i < l && 65 <= scoreEnc.charCodeAt(i);) {
                e += f * (scoreEnc.charCodeAt(i) - 65), f *= 58, ++i;
            }
            output += String.fromCharCode(e ^ t), ++i;
        }
        try {
        res = parseInt(output) > 0;
        }
        catch(e) {};
    }
    return res;
}

try {
    throw (new Error('exception'));
} catch(e) {
    const ln = e.stack.match(/anticheat\.js:(\d+)/);
    if (ln && ln.length > 2 && ln[1] !== 99) {
        disablePopup();   
    }
}

chrome.storage && chrome.storage.onChanged.addListener((changes, areaName) => {
    if (changes && changes.hasOwnProperty('scoreEnc') && typeof changes.scoreEnc === 'string' && !checkScore(changes.scoreEnc)) {
        disablePopup();
    }
});

try {
    throw (new Error('exception'));
} catch(e) {
    const ln = e.stack.match(/anticheat\.js:(\d+)/);
    if (ln && ln.length > 2 && ln[1] !== 114) {
        disablePopup();   
    }
}