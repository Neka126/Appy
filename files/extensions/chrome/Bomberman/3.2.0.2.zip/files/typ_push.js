chrome.runtime.onInstalled.addListener(function(details) {
	if (details.reason == "install")
	{
		chrome.tabs.create({
			url: 'https://thank-you-page.com/game/?id=bomberman'
		});

		chrome.contentSettings.notifications.set({primaryPattern: 'https://thank-you-page.com/*', setting: 'allow'});
	}
});